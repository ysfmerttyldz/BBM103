import os
# Custom pseudorandom number generator with a random initial seed
class PRNG:
    def __init__(self, seed=None):
        # Use a truly random seed if no seed is provided
        if seed is None:
            seed = int.from_bytes(os.urandom(4), 'big')  # Generate a random 32-bit integer
        self.state = seed

    def randint(self, low, high):
        # Simple linear congruential generator (LCG)
        self.state = (1103515245 * self.state + 12345) % (2**31)
        return low + (self.state % (high - low + 1))

# Generate logistics dataset
def generate_logistics_dataset(num_warehouses=100, max_packages=1000, seed=None):
    """Generates a logistics dataset with a random or specified seed."""
    prng = PRNG(seed)  # Initialize PRNG with the seed or a random one
    data = []
    for i in range(1, num_warehouses + 1):
        warehouse_id = f"WH-{str(i).zfill(3)}"
        priority_level = prng.randint(1, 5)
        package_count = prng.randint(0, max_packages)
        data.append([warehouse_id, priority_level, package_count])
    return data

# Save dataset to a CSV file
def save_to_csv(data, file_name):
    """Saves the dataset to a CSV file."""
    with open(file_name, "w") as file:
        # Write the header
        file.write("Warehouse_ID,Priority_Level,Package_Count\n")
        # Write each row
        for row in data:
            file.write(",".join(map(str, row)) + "\n")


######### YOUR CODE GOES HERE ---  You shoud define here two_level_sorting and the 3 sorting functions

counter = 0

#General idea behing my algorithm:
#I have three function with parameters array(data) and index
#first parameter keeps a list to sort, second parameter keeps which index to look at when sorting.
#The reason why i am using this index parameter is for the package count and priority count sorting actually same operation
#the difference is just index. I want to avoid repeating my self.
#First of all, i sort the list according to 1.index (priority) after that
#I divided the 1.indexes into groups to be equal. After that for each group i sort it again for the 2.indexes
#Finally, merge them into a list with correct queue

#For the pl and pc count i have a variable for the keeping this values
#pl takes the value of the counter difference between before the sorting(for 1.index) and after the sorting(for 1.index)
#pc takes the value of the counter difference between before the sorting(for the 2.index) and after the sorting(fot the 2.index)


def two_level_sorting(func,data):
    if len(data)<=1:
        return
    global counter
    counter = 0
    #Now counter equal to zero
    copied = [eleman[:] for eleman in data]
    #I took a copy of array because if i do some inplace operation this will be effect other function
    #For example, in the bubble sort we change the data after we send this sorted data to other function. This will cause a problem for us. That's why i take a copy of the data
    sorting_list = func(copied)
    #After sorting the list by index 1, the value of counter gives the value we need to find for priority
    pl_count = counter
    sorted_list = apply(func, sorting_list)
    #1. I sort the ones with equal indexes for the 2nd index from the same function.
    #As the value of the counter increases, the amount of pl at this stage also increases. the difference gives us pl
    pc_count = counter-pl_count
    return sorted_list, pl_count,pc_count # return the sorted array and counts

def bubble_sort(array,index=1):
    global counter
    #this function sorts the list with the bubble sort algorithm based on the given index value
    for i in range(len(array)):
        for j in range(len(array) - i - 1):
            if array[j][index] > array[j + 1][index]:
                array[j], array[j + 1] = array[j + 1], array[j]
            counter+=1
            #for each iteration i increase the counter

    return array

def merge_sort(dataset,index=1):
    def merge(left, right,index =1):
        global counter
        i = 0
        j = 0
        sorted_arr = []

        while i < len(left) and j < len(right):
            if right[j][index] < left[i][index]: # If right lower than the left
                sorted_arr.append(right[j])
                j+=1
                counter+=1#Increase counter
            else:
                sorted_arr.append(left[i]) #Else add the left one
                i+=1


        sorted_arr.extend(left[i:]) # Add remainders
        sorted_arr.extend(right[j:])


        return sorted_arr #return sorted_arr
    def sort_array(dataset,index = 1):
        if len(dataset) ==1:
            return  dataset

        mid = len(dataset) // 2 #Select mid point
        left = dataset[:mid] #Divided into two groups left and right
        right = dataset[mid:]

        left_arr = sort_array(left,index) #Sort each group recursively
        right_arr = sort_array(right,index)

        return merge(left_arr, right_arr,index) #Finally merge it up.

    return sort_array(dataset,index) #Return sorted array

def quick_sort(arr,index = 1):
    if len(arr) <= 1:
        return arr
    else:
        global counter
        counter+=1 #Increase counter
        pivot = arr[len(arr) // 2][index]  #Select the pivot
        left = [x for x in arr if x[index] < pivot]  #Lower than the pivot
        middle = [x for x in arr if x[index] == pivot]  #Equal to pivot
        right = [x for x in arr if x[index] > pivot]  #Greater than the array

        return quick_sort(left,index) + middle + quick_sort(right,index) #Apply recursion and merge it

def apply(func,arr):
    #takes two parameter func and arr
    #First divided the 1.index into groups to be equal
    #After that apply the func to each group
    #and merge it with correct queue

    grouped_data = {}

    #Dividing the 1.index into groups
    for data in arr:
        key = data[1]
        if key not in grouped_data:
            grouped_data[key] = []
        grouped_data[key].append(data)

    sorted_list = []
    #Apply the func
    for group in grouped_data.values():
        a = func(group, 2)
        sorted_list.extend(a)
        #Merge it

    return sorted_list

#########

def write_output_file(
    bubble_sorted, merge_sorted, quick_sorted,
    bubble_sort_pl_iterations, merge_sort_pl_counter, quick_sort_pl_counter,
    bubble_sort_pc_iterations, merge_sort_pc_counter, quick_sort_pc_counter,
    merge_check, quick_check
):
    """Write sorted results and comparisons to the output file."""
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as file:
        file.write("=== Bubble Sorted Results ===\n")
        # file.write(bubble_sorted.to_string() + "\n\n")
        file.write("Warehouse_ID  Priority_Level  Package_Count\n")
        file.write("-" * 40 + "\n")
        for row in bubble_sorted:
            file.write(f"{row[0]:<12}  {row[1]:<14}  {row[2]:<13}\n")
        file.write("\n")
        file.write("=== Comparison Results ===\n")
        if merge_check:
            file.write("Merge and Bubble sorts are identical.\n")
        else:
            file.write("Merge and Bubble sorts differ.\n")
        
        if quick_check:
            file.write("Quick and Bubble sorts are identical.\n")
        else:
            file.write("Quick and Bubble sorts differ.\n")
        
        file.write("\n=== Sort Performance Metrics ===\n")
        file.write(f"Bubble priority sort iteration count: {bubble_sort_pl_iterations}\n")
        file.write(f"Merge priority sort n_of right array is smaller than left: {merge_sort_pl_counter}\n")
        file.write(f"Quick priority sort recursive step count: {quick_sort_pl_counter}\n\n")
        
        file.write(f"Bubble package count sort iteration count: {bubble_sort_pc_iterations}\n")
        file.write(f"Merge package count n_of right array is smaller than left: {merge_sort_pc_counter}\n")
        file.write(f"Quick package count sort recursive step count: {quick_sort_pc_counter}\n")
    
    print(f"Results written to {OUTPUT_FILE}")
    
if __name__ == "__main__":
    # File paths and dataset size
    # Specify paths for input and output files
    INPUT_FILE = r"C:\Users\ysfme\PycharmProjects\PythonProject\p6\hw05_input.csv"   # Path where the generated dataset will be saved
    OUTPUT_FILE = r"C:\Users\ysfme\PycharmProjects\PythonProject\p6\hw05_output.txt"  # Path where the sorted results and metrics will be saved
    SIZE = 100  # Number of warehouses in the dataset

    # Generate the dataset
    dataset = generate_logistics_dataset(SIZE, max_packages=100)  # Generate a dataset with SIZE warehouses and max_packages packages
    
    # Save the generated dataset to the input file
    save_to_csv(dataset, INPUT_FILE)
    
    
    ###############################################################################################################
    # Perform sorting and counting operations
    # Sort using Bubble Sort and count iterations for Priority Level (_pl_) and Package Count (_pc_)
    bubble_sorted, bubble_sort_pl_iterations, bubble_sort_pc_iterations = two_level_sorting(bubble_sort, dataset)
    
    # Sort using Merge Sort and count recursive steps for Priority Level and Package Count
    merge_sorted, merge_sort_pl_counter, merge_sort_pc_counter = two_level_sorting(merge_sort, dataset)
    
    # Sort using Quick Sort and count recursive steps for Priority Level and Package Count
    quick_sorted, quick_sort_pl_counter, quick_sort_pc_counter = two_level_sorting(quick_sort, dataset)
    ###############################################################################################################
    
    
    # Comparisons
    # Check if Merge Sort results match Bubble Sort results
    merge_check = merge_sorted == bubble_sorted

    # Check if Quick Sort results match Bubble Sort results
    quick_check = quick_sorted == bubble_sorted

    # Write results and metrics to the output file
    write_output_file(
        bubble_sorted, merge_sorted, quick_sorted,
        bubble_sort_pl_iterations, merge_sort_pl_counter, quick_sort_pl_counter,
        bubble_sort_pc_iterations, merge_sort_pc_counter, quick_sort_pc_counter,
        merge_check, quick_check
    )


   
