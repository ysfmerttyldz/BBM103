import sys
import locale
import re

locale.setlocale(locale.LC_ALL, "en_US")

def number_of_words(paragraph): #finds how many words are in a given string
    #Logic: The length of get_all_words gives the total number of words.
    return len(get_all_words(paragraph)) #gives the word count

def number_of_sentences(paragraph):
    #Logic: I turned the three dots into an exclamation because when counting dots, 3 dots cause confusion. Then I counted the signs that can come at the end of the sentence.
    sentence_count = 0
    paragraph2 = paragraph.replace("...","!") #I replaced the 3 dots in the string with exclamation(a punctuation mark expected to be at the end of a sentence) points
    for i in range(len(paragraph2)):
        if paragraph2[i] in ["!","?","."]: #I reached the number of sentences by counting the punctuation marks at the end of the sentence
            sentence_count+=1
    return sentence_count

def ratio_between_word_n_sentence_count(word_count, sentence_count):
    #Logic: Find the ratio of the total number of words to the number of sentences
    return  word_count/sentence_count # I divided by word count by sentence count for get the ratio

def charachter_count_of_words(words):
    #Logic: the total length of the words in the list of words gives the word count
    count = 0
    for word in words:
        count+= len(word) # I find the number of letters then plus
    return count

def get_all_words(paragraph):
    #Logic:This regex code r"\b[\w'.,!?-]+\b" is used to extract words from string. This expression takes word boundaries (\b) to determine the start and end of words and this allows for the punctuations with in the words
    #[\w'.,!?-]+ shows that these type of characters can be multiple times
    words = re.findall(r"\b[\w'.,!?-]+\b", paragraph)
    return words

def find_shortest_word(paragraph):
    #Logic: First take the words, second determine the shortest lenght of the words thirdly get a list of shortest word via set(I use set because I do no want to saw one word for a multiple times
    #Lastly, I sort the shortest_words list according to decreasing frequency. For same frequency I sorted alphabetically
    words = get_all_words(paragraph) #gets all words
    shortest_lenght = len(min(words,key=len)) # Take the shortest word.
    shortest_words = list(set(word for word in words if len(word) == shortest_lenght)) # if there is more than one, it adds the unique one to avoid confusion
    shortest_words = sorted(shortest_words, key=lambda word: (-calculate_frequenciy(word, paragraph), word)) #sorts by word frequency and alphabetical order
    return shortest_words

def find_longest_word(paragraph):
    # Logic: First take the words, second determine the longest lenght of the words thirdly get a list of longest word via set(I use set because I do no want to saw one word for a multiple times
    # Lastly, I sort the longest_words list according to decreasing frequency. For same frequency I sorted alphabetically
    words = get_all_words(paragraph) #gets all words
    longest_lenght = len(max(words,key=len)) # Take the longest word.
    longest_words = list(set(word for word in words if len(word) == longest_lenght)) # if there is more than one, it adds the unique one to avoid confusion
    longest_words = sorted(longest_words, key=lambda word: (-calculate_frequenciy(word, paragraph), word)) #sorts by word frequency and alphabetical order
    return longest_words

def calculate_frequenciy(word,paragraph):
    #Logic: I get the all words, then i take the same words with parameter word into a list "thes" lastly I find the lenght of the list and divided into them
    words = get_all_words(paragraph) #get all words
    thes = list(wor for wor in words if wor == word)  # searches for the searched word and adds words to the list
    finding_word_count = len(thes) # takes count
    return finding_word_count/ number_of_words(paragraph) # return ratio between searched word/ number of words

def read_file(file_name):
    #Logic: I read the file through utf-8 because I want to avoided some problems related to encoding, I return lower because i want to avoid lower upper confusion
    with open(file_name,"r",encoding="utf-8") as file: #file parameter takes name of the .txt fil
        content = file.read() #reads inside the file
    return content.lower() #I used lower case to avoid upper case lower case confusion

def statistic(file,outputfile):
    #Logic: Take all the information from the metods related to information, Then start to write them through looking output text's structure

    input_file = open(file, "r")  # open file for reading
    output_file = open(outputfile, "w")   # open file for writing
    paragraph = read_file(file) # get string from file
    words = get_all_words(paragraph) # get all words
    wordcount = number_of_words(paragraph) # get word count of paragraph
    sentencecount = number_of_sentences(paragraph) # get sentence count of paragraph
    word_sentence_ratio = ratio_between_word_n_sentence_count(wordcount, sentencecount) # get word sentence ratio of paragraph
    character_count = len(paragraph) # get character count of paragraph
    character_just_word = charachter_count_of_words(words) # get character count(just words) of paragraph
    shortest_words = find_shortest_word(paragraph) # get shortest words of paragraph
    longest_words = find_longest_word(paragraph) # get longest words of paragraph
    hashmap = dict({word: calculate_frequenciy(word, paragraph) for word in words}) # word : frequency hashmap
    sorted_dict = dict(sorted(hashmap.items(), key=lambda x: (-x[1], x[0]))) # -x[1] means sort dict according deacreasing value, x[0] means sort alphabetically

    output_file.write(
        f"{f'Statistics about {file}':7} :\n" 
        f"{'#Words':<24}: {wordcount}\n"
        f"{'#Sentences':<24}: {sentencecount}\n"
        f"{'#Words/#Sentences':<24}: {word_sentence_ratio:.2f}\n"
        f"{'#Characters':<24}: {character_count}\n"
        f"{'#Characters (Just Words)':<24}: {character_just_word}\n"
    )

    if len(shortest_words) == 1: # if we have just 1 shortest word
        output_file.write(
            f"{f'The Shortest Word':24}: {shortest_words[0]:24} ({calculate_frequenciy(shortest_words[0],paragraph):.4f})\n"
        )
    else:
        output_file.write(f"{f'The Shortest Words':<24}:\n")
        for i in range(len(shortest_words)):
            output_file.write(f"{shortest_words[i]:<24} ({calculate_frequenciy(shortest_words[i],paragraph):.4f})\n")

    if len(longest_words) == 1: # if we have just 1 longest word
        output_file.write(
            f"{f'The Longest Word':24}: {longest_words[0]:24} ({calculate_frequenciy(longest_words[0],paragraph):.4f})\n"
        )
    else:
        output_file.write(f"{f'The Longest Words':<24}:\n")
        for i in range(len(longest_words)):
            output_file.write(f"{longest_words[i]:<24} ({calculate_frequenciy(longest_words[i],paragraph):.4f})\n")

    output_file.write(f"{f'Words and Frequencies':<24}:\n")

    for hash in sorted_dict:
        if hash == list(sorted_dict.items())[-1][0]: # if current has value equal last one, then we don't want to print another new line (\n)
            output_file.write(
                f"{f'{hash}':<24}: {sorted_dict[hash]:.4f}"
            )
            break
        output_file.write(  # if it is not equalt to last one then we print new line after writing
            f"{f'{hash}':<24}: {sorted_dict[hash]:.4f}\n"
        )

    output_file.flush() #force the immediate writing of buffered data
    output_file.close() # close after we're done
    input_file.close()  # close after we're done

def main():
    input_file = sys.argv[1] #takes input for input
    output_file = sys.argv[2] #takes input for output
    statistic(input_file,output_file) #execute statistic func

if __name__ == "__main__": # if the function name main execuse it
    main()