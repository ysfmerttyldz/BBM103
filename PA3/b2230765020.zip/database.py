import sys
import ast
import re

def create_table(parameter,tables):
    #Logic: I want to use dictionary for tables variable. I take the parameters tables and is_it_last as a parameter of the function.
    #parameters equal to command for example students id,name,age,major this is command. Be carefull, in the begining there is no CREATE_Table
    #The tables parameter is to get the variable with all tables.
    #is_it_last parameter is to get is it the last command. I took that because i wanted to control empty line. if this parameter equal to true then
    #after execution this command there should be no other empty lines
    #Logic: I basically use split for expand the command. Because there is just 2 part in our command table_name and columns. There is need to doing detailed spliting operations.
    #and there is no try except block. Because in our assignment this is impossible.
    table_name,columns = parameter.split(maxsplit=1)
    columns = columns.split(',')
    tables[table_name] = {"data":[],
                          "columns":columns}
    writer("CREATE",[f"Table '{table_name}' created with columns: {columns}"],tables,"-1")
    #Send it to the writer.
    return tables

def insert(parameter,tables):
    try:
        #There is a same pattern as with create_table func to get command.
        #After taking parameters add the data to given table_name table
        table_name,data = parameter.split(maxsplit=1)
        data = data.split(',')
        #Purpoose of this slicing "data[:len(tables[table_name]["columns"])]" that. For example table has a 4 column but data has a 5. Then just add add data's first 4 columns.
        tables[table_name]["data"].append(data[:len(tables[table_name]["columns"])])
        #The purpose of the converting tuple is in the given output_files there is a tuple. That's why i converted them to the tuple.
        writer("INSERT",[f"Inserted into '{table_name}': {tuple(data)}"],tables,table_name)
        return tables
    except Exception as e:
        #if there is any error this block going to execute and error_control function going to execute. I explain error_control func in his code block.
        error_control(e,"INSERT",table_name,[f"Table {table_name} not found",f"Inserted into '{table_name}': {tuple(data)}"],[""],tables)

def select(parameter,tables):
    try:
        #Firstly,takes the parameter and split up them into four group: table_name,columns,_(this one for WHERE word),conditions
        #for the convert conditions(string) to dictionary i use literal_eval func.
        table_name,columns,_,condition = parameter.split(maxsplit=3)
        condiction_dict = ast.literal_eval(condition)
        #I get the datas what is matched with the conditions. I will explain this function in his code block.
        selected = get_data_according_to_condition(parameter,tables)
        selected = [tuple(data) for data in selected]
        #Again convert to the tuple for the getting same output_file with given ones.
        writer("SELECT",[f"Condition: {condiction_dict}",f"Select result from '{table_name}': {selected}"],tables,"-1")
        return tables
    except Exception as e:
        not_found = str(e).split()[0].strip("'")
        #this not found variable gives us what is the not founded. For example if func didn't find the students table. not_found variable equal to students.
        error_control(e,"SELECT",table_name,[f"Table {not_found} not found",f"Condition: {condiction_dict}",f"Select result from '{table_name}': None"],
                      [f"Column {not_found} does not exist",f"Condition: {condiction_dict}",f"Select result from '{table_name}': None"],tables)

def update(parameter,tables):
    try:
        #There is a regex_code for expanding our parameter correctly.
        regex_code_for_split_input = r"(UPDATE|WHERE|[a-zA-Z_][a-zA-Z0-9_]*|\{[^}]*\})"
        table_name,update,_,condition = re.findall(regex_code_for_split_input,parameter)
        #regular expression will split our string according to his code and after that we will find our variables correctly.
        update_dict = ast.literal_eval(update)
        #Convert to update string to the dictionary
        condition_dict = ast.literal_eval(condition)
        selected = get_data_according_to_condition(f'{table_name} * WHERE {condition}',tables)
        #Takes datas what is the matched to the condition
        update_count = 0
        #updates variables keeps updated value
        updates = []

        for data in selected:
            update_row = list(data)  # Mevcut veriyi kopyala
            for update_key, update_value in update_dict.items():
                column_index = tables[table_name]["columns"].index(update_key)
                update_row[column_index] = update_value  # Güncellemeyi uygula
            updates.append(update_row)

        #After finding updates variable i apply them to the table
        for i, data in enumerate(selected):
            index = tables[table_name]["data"].index(data)
            tables[table_name]["data"][index] = updates[i]
            update_count += 1
        #For all matched datas, code updated datas.
        writer("UPDATE",[f"Updated '{table_name}' with {update_dict} where {condition_dict}",f"{update_count} rows updated."],tables,table_name)
        return tables
    except Exception as e:
        not_found = str(e).split()[0].strip("'")
        #not_found equal what is the thing not founded.
        error_control(e,"UPDATE",table_name,[f"Updated '{table_name}' with {update_dict} where {condition_dict}",f"Table {table_name} not found","0 rows updated."],
                      [f"Updated '{table_name}' with {update_dict} where {condition_dict}",f"Column {not_found} does not exist",f"0 rows updated."],tables,will_table_write=table_name)

def count(parameter,tables):
    try:
        #There is same pattern for getting variables from the parameter.
        table_name,_,condition = parameter.split(maxsplit=2)
        selected = tuple(get_data_according_to_condition(f'{table_name} * WHERE {condition}',tables))
        #Get the datas what is matched with the conditions
        writer("COUNT",[f"Count: {len(selected)}",f"Total number of entries in '{table_name}' is {len(selected)}"],tables,"-1")
        return tables
    except Exception as e:
        not_found = str(e).split()[0].strip("'")
        #Same structure. not_found equal what is not founded.
        error_control(e,"COUNT",table_name,[f"Table {table_name} not found",f"Total number of entries in '{table_name}' is 0"],
                      [f"Column {not_found} does not exist",f"Total number of entries in '{table_name}' is 0"],tables)

def delete(parameter,tables):
    try:
        #There is a same pattern for taking variables from the parameter.
        if " " in parameter:
            table_name, _, condition = parameter.split(maxsplit=2)
        else: #If there are no spaces in the parameter, this parameter is equal to the table name only. It means delete all data.
            table_name = parameter
            data_count = len(tables[table_name]["data"])
            tables[table_name]["data"] = []
            writer("DELETE", [f"Deleted from '{table_name}'", f"{data_count} rows deleted."],
                   tables, table_name)
            return
        condtion_dict = ast.literal_eval(condition)
        #Convert condition to the dictionary via literal_eval func.
        selected = get_data_according_to_condition(f'{table_name} * WHERE {condition}',tables)
        #get the datas what is matched with the condition
        delete_count = 0
        #what is the count of deleting
        for data in selected:
            tables[table_name]["data"].remove(tables[table_name]["data"][tables[table_name]["data"].index(data)])
            #Firstly, will found the index of the data and remove it. After that delete_count will be increase 1.
            delete_count += 1
        writer("DELETE",[f"Deleted from '{table_name}' where {condtion_dict}",f"{delete_count} rows deleted."],tables,table_name)
        return tables
    except Exception as e:
        not_found = str(e).split()[0].strip("'")
        error_control(e,"DELETE",table_name,[f"Deleted from '{table_name}' where {condtion_dict}",f"Table {table_name} not found","0 rows deleted."],
                      [f"Deleted from '{table_name}' where {condtion_dict}",f"Column {not_found} does not exist","0 rows deleted."],tables,will_table_write=table_name)

def join(parameter,tables):
    try:
        #There is a same pattern for getting variables from the parameter.
        table_names, _, key = parameter.split(maxsplit=2)
        table_names = table_names.split(',')
        table_name1,table_name2 = table_names[0],table_names[1]
        table1,table2 = tables[table_name1],tables[table_name2]
        cols1,data1,cols2,data2 = table1["columns"],table1["data"],table2["columns"],table2["data"]
        combined_columns = cols1 + cols2
        #result table's columb will be equal to the combined_columns and this is the cols1+cols2
        result = []
        #this variables keeps datas of the join tables
        for data1 in table1["data"]:#for all datas which is in the first table, code will control all datas which is in the second table.
            for data2 in table2["data"]:
                if data1[cols1.index(key)] == data2[cols2.index(key)]: #if data1's information equal to the data2's information on key. For example key equal major
                    # table1's column's 0.index = major and table2's column's 3.index major this if statement control that.
                    joined_record = data1 + data2 #And sum them after that add this summation to the result list.
                    result.append(joined_record)
        #After operation code going to create this join table with combined_columns and result
        tables["Joined Table"] = {'columns': combined_columns, 'data': result}
        writer("JOIN", [f"Join tables {table_name1} and {table_name2}", f"Join result ({len(result)} rows):"],tables,
               "Joined Table")
        return tables
    except Exception as e:
        not_found = str(e).split()[0].strip("'")
        not_found_table_name = [t_name for t_name in [table_name1,table_name2] if t_name not in tables.keys()]
        #if not founded table count greater than 0 that means there is not problem in tables. There is a problem in column.
        if len(not_found_table_name) >0: writer("JOIN",[f"Join tables {table_name1} and {table_name2}", f"Table {not_found} does not exist"],tables,"-1")
        else: writer("JOIN",[f"Join tables {table_name1} and {table_name2}", f"Column {not_found} does not exist"],tables,"-1")

def get_data_according_to_condition(parameter,tables):
    #There is a same pattern to get variable's values from the parameter.
    table_name,columns,_,condition = parameter.split(maxsplit=3)
    if columns == "*": #control this * punctuation.
        columns = tables[table_name]["columns"]
    else: columns = columns.split(',') #if not equal this * then split up from the getting columns.
    condition_dict = ast.literal_eval(condition)
    selected_datas = [data for data in tables[table_name]["data"] if all(str(data[tables[table_name]["columns"].index(key)]) == str(value) for key,value in condition_dict.items())]
    #if data meets all conditions then this one is suitable for selecting. For doing this we control datas from all conditions. if all conditions gives us a true then it is okey.We can select this data.
    #all makes this for us. If all of the conditions gives us a true then this if statement is okey.
    indexes = [tables[table_name]["columns"].index(column) for column in columns]
    #this list contains what is the index of the wanted columns.
    #and give just wanted columns datas.
    result = [[seleted_with_columns[index]for index in indexes] for seleted_with_columns in selected_datas]
    return result

def error_control(e,command,table_name,table_not_found,column_not_found,tables,will_table_write = "-1"):
    #This function is very crucial for controlling errors. Except the join function all of the functions are about specifically one table.
    #That's why if not found equal to the table_name that means we couldnt found the table. Otherwise we could not found the column.
    #For specifically join function i control two tables in join function code.
    #I did it this way because the only errors we need to check in this assignment are whether there are tables and columns. This way is more targeted. Otherwise, doing it this way will surely cause errors.
    not_found = str(e).split()[0].strip("'")
    if not_found == table_name:
        writer(command,table_not_found,tables,"-1")
        #if we couldn't find table then send the error about it.
    else:
        #otherwise send error about column not found.
        writer(command,column_not_found, tables,will_table_write)

def process_inputs():
    input = open(sys.argv[1],"r").readlines()
    tables ={}
    for input_line_index in range(len(input)): #Control all of the lines in the input text.
        input_line = input[input_line_index].strip()
        if input_line == "": #if line is empty then do not any operation about it. Just skip it.
            continue
        command = input_line.split(maxsplit=1) # takes what is the operation is it CREATE_TABLE is it INSERT or whatever. We are going to call function according to this variable's value.
        if command[0] == "CREATE_TABLE": create_table(command[1],tables)
        if command[0] == "INSERT": insert(command[1],tables)
        if command[0] == "SELECT": select(command[1],tables)
        if command[0] == "UPDATE": update(command[1],tables)
        if command[0] == "COUNT": count(command[1],tables)
        if command[0] == "DELETE": delete(command[1],tables)
        if command[0] == "JOIN": join(command[1],tables)

def writer(command,lines,tables,table_name="-1"):
    #This function is our main writing function.
    #there is to variable called hashtah and hashtag2 these are for the titles of our command.
    hashtag = "######################"
    hashtag2 = "#########################\n"
    if command == "JOIN": #I realize that for the join function there is a mone hashtag for the titles. that's why i do that.
        hashtag = hashtag + "#"
        hashtag2 = "#"+hashtag2

    print(f"{hashtag} {command} {hashtag2}",end="") # print title of the command.
    for line in lines: #print lines
        print(line)
    if table_name!= "-1": # if we want to print current state of the table then we gave table name to writer function. -1 is a default value. If table_name not given than code will not print current state of table
        write_table(table_name,tables)
    print("#######################################################\n")

def write_table(table_name,tables):
    def write_data(list_of_data, max_lenghts):# this function writes datas. lines.
            for data in list_of_data: #for all data in the list
                formatted = "|" # first write this.
                will_print = formatted
                for max_index in range(len(max_lenghts)): # this operation will be lenght of the columns times.
                    formatted = f" %-{max_lenghts[max_index]}s |" # format them according to max_lenght array.
                    will_print += formatted % data[max_index]
                print(will_print) #after we found the what is the data will write we will write it.
    def write_complete(list_of_column, max_lenghts, list_of_data):
            header = ""
            for lenght in max_lenghts: # this for statememnt founds suitiable string like this +----+---+
                header += "+"
                header += "-" * (lenght + 2)
            header += "+"
            print(header) #print it
            write_data([list_of_column], max_lenghts) #write our columns.
            print(header)# again print it.
            write_data(list_of_data, max_lenghts)# print our datas.
            print(header)# and print again.
    def get_max_lenght(columns, datas): #this function will find our count of spaces for formating.
            max_lenghts = []
            for i in range(len(columns)): #do same operation for the all colums
                will_look = []
                will_look.append(columns[i]) #firstly i add the columns for comparison to get maximum lenght of the string.
                for data in datas: #then add datas.
                    will_look.append(str(data[i]))
                max_lenghts.append(len(max(will_look, key=len))) #maxlenght add the maximum lenght.
            return max_lenghts
    #this is the function for writing current state of the given table.
    try:
        print(f"\nTable: {table_name}") #before the writing table will write Table: table_Name
        table = tables[table_name]
        max_lenghts = get_max_lenght(table["columns"], table["data"])
        write_complete(table["columns"], max_lenghts, table["data"])
    except Exception as e:
        print(f"Undetermined error occurs: {e}")

def main():
    process_inputs()

if __name__ == "__main__":
    main()