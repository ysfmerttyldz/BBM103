import sys
import time

def get_cost_and_grid():
    #Logic: I take the file. I read the first line for the get cost.
    file = open(sys.argv[1], "r")
    costs = file.readline().split()
    costs = [int(cost) for cost in costs]
    grid = []
    #I read all lines for creating grid array
    for line in file:
        grid.append(list(line.split()))
    return costs, grid

def get_cost(grid, pos, costs):
    #Logic: Takes the grid pos and costs list and returns the cost of the cell at the given pos.
    #This function calculates cost of the given position.
    row, col = pos
    cost1, cost2, cost3 = costs[:3]
    cost = cost1 #if we don't change cost, then cost will equal to cost1
    for_cost2 = [(1, 0), (-1, 0), (0, 1), (0, -1)]#For the control horizontal and vertical cells for cost3
    for dirx, diry in for_cost2:
        if isValidNode(grid, (row + dirx, col + diry)) and grid[row + dirx][col + diry] == "0": #if a vertical or horizontal neighbor cell exists and is equal to 0, set cost equal to cost3
            cost = cost3
            return cost # and return it. Because if the the cell's cost equal to cost3 that we should not control other scenerious. In this way, we avoid the confusing about calculating cost.

    for_cost3 = [(1, 1), (-1, -1), (-1, 1), (1, -1)] #for the control of cross-neighboring cells
    for dirx, diry in for_cost3:
        if isValidNode(grid, (row + dirx, col + diry)) and grid[row + dirx][col + diry] == "0": #if a cross-neighbour cell exists and is equal to 0, set cost equal to cost2
            cost = cost2

    return cost

def isValidNode(grid, pos):
    #Logic: Takes the grid and pos and checks whether the pos is in that grid or not as true or false
    row, col = pos
    return False if (row < 0 or row >= len(grid)) or (col < 0 or col >= len(grid[0])) else True

def rec(current_path, current_cost, cur_pos, visited, grid, costs, memo,cur_min):
    #Logic: I use the depth first search alghoritim actually for finding minimum cost route.
    #I sent the current_path and current_cost data.This variables keeps path and cost to get to this cell.
    #Current pos keeps the row and column data (row,col) tuple
    #Visited set for the while trying to neighbour cells i want to avoided multiple times control. If alghoritim visit the cell then mark it visited.
    #Costs is cost array such as [1,2,3] or [1,4,7].
    #cur_min keeps the lowest cost path found until it reads this cell

    x, y = cur_pos #I split the cur_pos for getting row and column position.
    if not isValidNode(grid, cur_pos) or cur_pos in visited or grid[x][y] == "0": #Do not process if the received pos is not valid, or if it was checked while doing dfs, or if the cell in that pos is equal to 0.
        return

    if cur_pos not in visited:#Visit if not visited
        visited.add(cur_pos)

    if  cur_pos in memo and memo[cur_pos] <= current_cost:
        return
    #I used the memoization method from dynamic programming to make it work faster.
    #I kept the previously checked positions, so if I come to the same point again, I used the data I calculated before and gained speed because I did not calculate it again.

    #I update the memoization set
    memo[cur_pos] = current_cost + get_cost(grid, cur_pos, costs)

    #Update the current_cost and current path for other recursion calls and calculations.
    current_cost += get_cost(grid, cur_pos, costs)
    current_path.append(cur_pos)

    goals = [(i,len(grid[0])-1) for i in range(len(grid[0]))]
    #These are points that may appear to the right of the grid

    if cur_pos in goals:#If the current position has reached the far right of the grid
        if cur_min == []: #If cur_min equal to empty. Just append result. Because there is no data for comparison.
            cur_min.append((current_cost,current_path))
        else: #If it is not empyt
            if current_cost< cur_min[0][0]:#Control for the getting minimum cost, if current_cost lower than cur_min cost append.
                #I just write < instead of <= because if they are equal, we want to take the one first I found the result. That's why i did not do any operation in this situtation.
                cur_min.clear() #For keeping just the current minimum i clear the list
                cur_min.append((current_cost,current_path)) # Append our minimum
        return cur_min #return the list

    new_visited = visited.copy()
    #A copy of the visited set is made in each recursive call to keep each path independent. This ensures that each recursion doesn't affect others,
    # and previously visited cells are not revisited in the current path.

    #Recursion calls for neighbours of the current pos. Start the recursion for the right,up,down,left neighbours respectively.
    rec(current_path[:], current_cost, (x, y + 1), new_visited, grid, costs, memo,cur_min)
    rec(current_path[:], current_cost, (x - 1, y), new_visited, grid, costs, memo,cur_min)
    rec(current_path[:], current_cost, (x + 1, y), new_visited, grid, costs, memo,cur_min)
    rec(current_path[:], current_cost, (x, y - 1), new_visited, grid, costs, memo,cur_min)

    return cur_min

def minimum_cost_path():
    costs, grid = get_cost_and_grid()#Takes the costs and grid from the function
    result = [] #This list for our result
    memo = {} #This set for the memoization
    cur_min = [] #This array for getting cur_min
    for i in range(len(grid)): #For starting points
        returned = rec([], 0, (i, 0), set(), grid, costs, memo, cur_min)#Start our recursive func.
        if returned != None: result = returned.copy() #I copied it because i want to avoid aliasing problems.

    if len(result) == 0: writer(False,grid)
    else: writer(len(result) != 0,grid ,result[0])
    #Write our result

def writer(founded,grid,minimum_cost_route=[]): #I define shortest with default value because we may not find the way
    output_file = open(sys.argv[2], "w")

    if founded == False: # If we do not found possible route
        output_file.write("There is no possible route!") # Just write this
    else:
        output_file.write(f"Cost of the route: {minimum_cost_route[0]}\n") #First right the cost of the route
        for pos in minimum_cost_route[1]: #for our minimum cost route
            row,column = pos
            if isValidNode(grid,pos): #I control it again in order to avoiding problems
                grid[row][column] = "X" #Change it to X
        for i, row in enumerate(grid): #For other cells i did not any changes.
            row_str = ' '.join(row) #Prepare row for writing.
            if i < len(grid) - 1: # For avoiding extra empty line
                output_file.write(f'{row_str}\n') #Write the row
            else:
                output_file.write(row_str) #For last row i did not write empty line

def main():
    #Start our algorithm
    start_time = time.time()
    minimum_cost_path()
    print(time.time() - start_time)

if __name__ == "__main__":
    main()
